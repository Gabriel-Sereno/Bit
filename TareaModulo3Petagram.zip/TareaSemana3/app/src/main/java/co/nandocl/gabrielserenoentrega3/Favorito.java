package co.nandocl.gabrielserenoentrega3;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class Favorito extends AppCompatActivity {

    private RecyclerView recyclerViewMascota;
    private ReciclerViewAdaptador adaptadorMascota;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favorito);

        recyclerViewMascota = findViewById(R.id.reciclerMascota);
        recyclerViewMascota.setLayoutManager(new LinearLayoutManager(this));

        adaptadorMascota = new ReciclerViewAdaptador(obtenerMascotas());
        recyclerViewMascota.setAdapter(adaptadorMascota);
    }

    public List<MascotaModelo> obtenerMascotas(){
        List<MascotaModelo> mascota = new ArrayList<>();

        mascota.add(new MascotaModelo("TOBU", 3, R.drawable.ct4));
        mascota.add(new MascotaModelo("KUMA", 5, R.drawable.ct6));
        mascota.add(new MascotaModelo("FLOR", 1, R.drawable.ct2));
        mascota.add(new MascotaModelo("LOQUI", 2, R.drawable.ct3));
        mascota.add(new MascotaModelo("CHICHO", 0, R.drawable.ct1));
        mascota.add(new MascotaModelo("ROBI", 4, R.drawable.ct5));

        return mascota;
    }
}