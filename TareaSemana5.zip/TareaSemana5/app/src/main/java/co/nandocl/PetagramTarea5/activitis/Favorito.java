package co.nandocl.PetagramTarea5.activitis;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.os.Bundle;
import android.view.View;

import java.util.List;

import co.nandocl.PetagramTarea5.Pojo.MascotaModelo;
import co.nandocl.PetagramTarea5.R;
import co.nandocl.PetagramTarea5.adapters.ReciclerViewAdaptador;
import co.nandocl.PetagramTarea5.presenter.Presenter;

public class Favorito extends AppCompatActivity {

    private RecyclerView recyclerViewMascota;
    private ReciclerViewAdaptador adaptadorMascota;
    private View v;
    private Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favorito);

        recyclerViewMascota = findViewById(R.id.reciclerMascota);
        recyclerViewMascota.setLayoutManager(new LinearLayoutManager(this));

        adaptadorMascota = new ReciclerViewAdaptador(obtenerMascotas());
        recyclerViewMascota.setAdapter(adaptadorMascota);
    }

    public List<MascotaModelo> obtenerMascotas(){
//        List<MascotaModelo> mascota = new ArrayList<>();
//        mascota.add(new MascotaModelo("Chani", 3, R.drawable.ct4));
//        mascota.add(new MascotaModelo("Lana", 5, R.drawable.ct6));
//        mascota.add(new MascotaModelo("Pepo", 1, R.drawable.ct2));
//        mascota.add(new MascotaModelo("Leo", 2, R.drawable.ct3));
//        mascota.add(new MascotaModelo("Rugo", 0, R.drawable.ct1));
//        return mascota;

        //        get favotritos
        Presenter pre = new Presenter(v, this);
        return pre.getFavs();
    }
}